package jogodavelha;

public class Jogador {
    private char simbolo;
    private boolean jogadorHumano;

    public Jogador(char simbolo, boolean jogadorHumano) {
        this.simbolo = simbolo;
        this.jogadorHumano = jogadorHumano;
    }

    public char getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(char simbolo) {
        this.simbolo = simbolo;
    }

    public boolean isJogadorHumano() {
        return jogadorHumano;
    }

    public void setJogadorHumano(boolean jogadorHumano) {
        this.jogadorHumano = jogadorHumano;
    }
    public void marcarJogada(TabuleiroJogoDaVelha tab){
        tab = new TabuleiroJogoDaVelha(this,this);
        
        
    }
}
