package jogodavelha;

public class TabuleiroJogoDaVelha {
    private final char tabuleiro[][] = new char[2][2];
    private final Jogador []jogadores = new Jogador[1];
    private int jogadorAtual;
    public TabuleiroJogoDaVelha(Jogador A, Jogador B){
        jogadores[0] = A;
        jogadores[1] = B;
        this.jogadorAtual = 0;
        resetar();
    }
    public final void resetar(){
        for (int l=0;l<3;l++){
            for (int c=0;c<3;c++){
                tabuleiro[l][c] = ' ';
            }
        }
    }
    public void marcaJogada(Posicao p){
        this.tabuleiro[p.getLinha()][p.getColuna()] = getSimboloJogadorAtual();
        //Marca o símbolo do jogador atual no tabuleiro.
    }
    
    public boolean estaMarcada(Posicao p){
        return tabuleiro[p.getLinha()][p.getColuna()] != ' '; 
        //Se a posição no tabuleiro for diferente de ' ' o retorno será verdadeiro.
    }
    public Jogador alternajogador(){
        if (jogadorAtual == 0){
            jogadorAtual++; //Alterna o jogador para jogadorAtual = 1.
            return jogadores[0];
        }
        else{
            jogadorAtual--; //Alterna o jogador para jogadorAtual = 0.
            return jogadores[1];
        }
    }
    public char getSimboloPosicao(Posicao p){
       return tabuleiro[p.getLinha()][p.getColuna()] = getSimboloJogadorAtual();
    }
    public char getSimboloJogadorAtual(){
       return alternajogador().getSimbolo(); 
       //Retorna o símbolo, de acordo com o jogador atual
    }
    public boolean jogadorAtualHumano(){
        return alternajogador().isJogadorHumano() == true; 
        //Se o jogador atual for humano então o método retorna true. 
    }
    public boolean checarLinhas(){
        for(int i=0;i<3;i++){
            return ((tabuleiro[i][0] & tabuleiro[i][1]) & tabuleiro[i][2]) == getSimboloJogadorAtual();
            //Checa todas as linhas, e se o símbolo das linhas forem iguais então retorna verdadeiro.
        }
        return false;
    }
    public boolean checarColunas(){
        for(int j=0;j<3;j++){
            return ((tabuleiro[0][j] & tabuleiro[1][j]) & tabuleiro[2][j]) == getSimboloJogadorAtual();
            //Checa todas as colunas, e se o símbolo das coluna forem iguais então retorna verdadeiro.
        }
        return false;
    }
    public boolean checarDiagonais(){
        //Analisa as duas possibilidas de diagonais e se uma delas for verdadeira
        //então o método retorna verdadeiro.
        if(((tabuleiro[0][0] & tabuleiro[1][1]) & tabuleiro[2][2]) == getSimboloJogadorAtual())
            return true;
        else 
            return ((tabuleiro[2][0] & tabuleiro[1][1]) & tabuleiro[0][2]) == getSimboloJogadorAtual();
    }
    public boolean deuVelha(){
        return checarDiagonais() == false;
    }
}